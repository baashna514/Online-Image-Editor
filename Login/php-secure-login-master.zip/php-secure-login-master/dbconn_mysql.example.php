<?php

$mysqli = new mysqli('localhost', 'username', 'password', 'login_test_database');

?>